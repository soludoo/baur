# -*- coding: utf-8 -*-
# Powered by Kanak Infosystems LLP.
# © 2020 Kanak Infosystems LLP. (<https://www.kanakinfosystems.com>).
{
    'name': 'Base Baur',
    'version': '1.0',
    "summary": '',
    'description': """ """,
    "category": "Sales",
    'author': 'Kanak Infosystems LLP.',
    'website': 'https://www.kanakinfosystems.com',
    'images': '',
    'depends': ['sale_management'],
    'data': [
        'views/sale.xml'
    ],
    'installable': True,
}
